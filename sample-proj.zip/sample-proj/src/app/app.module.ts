import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomePageComponent } from './home-page/home-page.component';
import { MapComponent } from './map/map.component';
import {AgmCoreModule } from '@agm/core'
import { HttpClientModule } from '@angular/common/http';
import { DetailsComponent } from './details/details.component';

import { SwiperModule } from 'angular2-useful-swiper';
import { SearchBoxComponent } from './search-box/search-box.component';
import { FooterComponent } from './footer/footer.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
  declarations: [
    AppComponent,
    HomePageComponent,
    MapComponent,
    DetailsComponent,
    SearchBoxComponent,
    FooterComponent,
 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AgmCoreModule.forRoot({apiKey:'AIzaSyBOQcBlbuSNv1F9GHCp8BAp6ZfDJoRLjXQ'}),
    HttpClientModule,
    SwiperModule,
    BrowserAnimationsModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
