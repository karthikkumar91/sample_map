
import { Component, OnInit, OnChanges } from '@angular/core';
import {ApiCallService} from '../api-call.service'
import {trigger, transition, style, animate, query, stagger} from '@angular/animations';
@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  animations: [
    trigger('listAnimation', [
      transition('* => *', [ // each time the binding value changes
        query(':leave', [
          stagger(100, [
            animate('0.5s', style({ opacity: 0 }))
          ])
        ], { optional: true }),
        query(':enter', [
          style({ opacity: 0 }),
          stagger(100, [
            animate('0.5s', style({ opacity: 1 }))
          ])
        ], { optional: true })
      ])
    ])
  ],
  styleUrls: ['./map.component.css']
})
export class MapComponent implements OnInit {
result:any;

// items:any=[{id: 0, name: "policy001"},
// {id: 2, name: "policy002"},
// {id: 3, name: "policy003"},
// {id: 4, name: "policy004"},
// {id: 5, name: "policy005"},   ]

  constructor(private api : ApiCallService) {

   }
 
  ngOnInit() {
    navigator.geolocation.getCurrentPosition((position) => { 
      console.log("Got position", position.coords);
      this.lat = position.coords.latitude; 
      this.lng = position.coords.longitude;
      //this.result=this.api.getdetails;
      this.api.getdetails(value=>{
        console.log(value.venues);
        this.result=value.venues;
        for(let i=0;i<this.result.length;i++){
          console.log(this.result[i].id)
        }
        console.log(this.result[0].id)
      }); 
    });
    this.items.length ? this.hideItems() : this.showItems();
  }
  lat: number = 13.37999359999999; 
  lng: number =74.739712;
  zoom: number = 14;
  items = [];
  // logAnimation(_event) {
  //   console.log(_event)
  // }
  showItems() {
    [0, 1, 2, 3, 4, 6, 7, 8, 9, 10].map((i) => {
      this.items.push("User Number - " + i)
    })

  }

  hideItems() {
    this.items = [];
  }
}
